package com.example.aspacelifeCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AspacelifeCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
