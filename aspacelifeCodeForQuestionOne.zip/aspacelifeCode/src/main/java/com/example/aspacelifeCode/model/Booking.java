package com.example.aspacelifeCode.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class Booking {
    private long id;
    private long userId;
    private long spaceId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;


}
