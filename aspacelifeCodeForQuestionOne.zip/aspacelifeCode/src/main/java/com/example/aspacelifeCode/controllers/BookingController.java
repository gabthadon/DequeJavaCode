package com.example.aspacelifeCode.controllers;

import com.example.aspacelifeCode.model.Booking;
import com.example.aspacelifeCode.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

@RestController
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping
    public Page<Booking> getAllBookings(@RequestParam(required = false) String startDate,
                                        @RequestParam(required = false) String endDate,
                                        @RequestParam(required = false) String status,
                                        Pageable pageable) {
        return bookingService.getAllBookings(startDate, endDate, status, pageable);
    }
}