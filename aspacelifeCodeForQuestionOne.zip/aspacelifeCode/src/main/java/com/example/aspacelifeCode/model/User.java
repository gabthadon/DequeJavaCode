package com.example.aspacelifeCode.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User {
    private long id;
    private String name;
    private String email;

    // getters and setters
}
