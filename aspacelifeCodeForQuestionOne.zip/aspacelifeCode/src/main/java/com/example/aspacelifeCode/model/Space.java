package com.example.aspacelifeCode.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Space {
    private long id;
    private String name;
    private boolean available;


}
