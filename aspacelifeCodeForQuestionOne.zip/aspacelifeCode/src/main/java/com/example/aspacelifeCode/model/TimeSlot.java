package com.example.aspacelifeCode.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;

@Setter
@Getter
public class TimeSlot {
    private LocalTime startTime;
    private LocalTime endTime;


}
