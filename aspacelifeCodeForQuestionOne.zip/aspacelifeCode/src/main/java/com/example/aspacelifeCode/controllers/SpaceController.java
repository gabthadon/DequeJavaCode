package com.example.aspacelifeCode.controllers;

import com.example.aspacelifeCode.model.Booking;
import com.example.aspacelifeCode.model.Space;
import com.example.aspacelifeCode.model.TimeSlot;
import com.example.aspacelifeCode.service.SpaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/spaces")
public class SpaceController {

    @Autowired
    private SpaceService spaceService;

    @GetMapping
    public Page<Space> getAllSpaces(@RequestParam(required = false) Boolean available, Pageable pageable) {
        return spaceService.getAllSpaces(available, pageable);
    }

    @GetMapping("/{id}/bookings")
    public Page<Booking> getBookingsForSpace(@PathVariable long id, @RequestParam(required = false) String startDate,
                                             @RequestParam(required = false) String endDate, Pageable pageable) {
        return spaceService.getBookingsForSpace(id, startDate, endDate, pageable);
    }

    @GetMapping("/{id}/availability")
    public List<TimeSlot> getAvailableTimeSlots(@PathVariable long id) {
        return spaceService.getAvailableTimeSlots(id);
    }
}
