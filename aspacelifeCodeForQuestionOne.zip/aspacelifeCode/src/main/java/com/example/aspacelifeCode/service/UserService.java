package com.example.aspacelifeCode.service;


import com.example.aspacelifeCode.model.User;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    // In-memory storage for users
    private List<User> users = new ArrayList<>();

    public Page<User> getAllUsers(Pageable pageable) {
        // Implement paginated retrieval of users from the in-memory list
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), users.size());
        return new PageImpl<>(users.subList(start, end), pageable, users.size());
    }
}
