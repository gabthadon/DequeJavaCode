package com.example.aspacelifeCode.service;

import com.example.aspacelifeCode.model.Booking;
import com.example.aspacelifeCode.model.Space;
import com.example.aspacelifeCode.model.TimeSlot;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SpaceService {

    // In-memory storage for spaces
    private List<Space> spaces = new ArrayList<>();

    public Page<Space> getAllSpaces(Boolean available, Pageable pageable) {
        // Implement paginated retrieval of spaces from the in-memory list, filtered by availability if provided
        List<Space> filteredSpaces = (available == null) ? spaces : spaces.stream().filter(space -> space.isAvailable() == available).collect(Collectors.toList());
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), filteredSpaces.size());
        return new PageImpl<>(filteredSpaces.subList(start, end), pageable, filteredSpaces.size());
    }

    public Page<Booking> getBookingsForSpace(long id, String startDate, String endDate, Pageable pageable) {
        // Implement paginated retrieval of bookings for the specific space, filtered by date range if provided
        // This is a placeholder implementation
        return Page.empty(pageable);
    }

    public List<TimeSlot> getAvailableTimeSlots(long id) {
        // Implement retrieval of available time slots for the space
        // This is a placeholder implementation
        return new ArrayList<>();
    }
}
